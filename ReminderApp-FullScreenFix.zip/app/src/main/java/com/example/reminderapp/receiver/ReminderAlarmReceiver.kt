package com.example.reminderapp.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.reminderapp.data.ReminderDatabase
import com.example.reminderapp.notification.AlarmScheduler
import com.example.reminderapp.notification.NotificationHelper
import com.example.reminderapp.ui.ReminderAlarmActivity
import com.example.reminderapp.utils.QuietHours
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Triggered by AlarmManager when a reminder is due.
 *
 * Strategy:
 *  1. Post a high-priority ongoing notification (Complete + Snooze actions).
 *     This is the safety net — it always shows even if everything else fails.
 *  2. ALSO directly start the full-screen ReminderAlarmActivity. This is what
 *     gives the user the "incoming-call" alarm experience instead of a quiet
 *     banner. Direct activity start from the background works as long as the
 *     SYSTEM_ALERT_WINDOW permission is granted; on Android 10+ it also works
 *     when the activity has launched recently or has special use-case flags.
 *  3. Re-check quiet hours one final time before doing anything user-visible.
 *  4. For repeating reminders, schedule the next occurrence.
 */
class ReminderAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val reminderId = intent.getLongExtra(AlarmScheduler.EXTRA_REMINDER_ID, -1L)
        if (reminderId == -1L) return

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = ReminderDatabase.getInstance(context).reminderDao()
                val reminder = dao.getById(reminderId) ?: return@launch
                if (!reminder.isEnabled) return@launch

                val now = System.currentTimeMillis()
                val scheduler = AlarmScheduler(context)

                val inQuietHours = reminder.quietHoursEnabled &&
                    QuietHours.isInQuietHours(
                        now,
                        reminder.quietStartHour,
                        reminder.quietEndHour
                    )

                if (!inQuietHours) {
                    // Post the persistent notification (safety net).
                    NotificationHelper.showReminderNotification(context, reminder)

                    // Also try to launch the full-screen alarm activity directly.
                    // This is what gives the "incoming-call" experience.
                    try {
                        val alarmIntent = Intent(context, ReminderAlarmActivity::class.java)
                            .putExtra(ReminderAlarmActivity.EXTRA_REMINDER_ID, reminder.id)
                            .addFlags(
                                Intent.FLAG_ACTIVITY_NEW_TASK or
                                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                                    Intent.FLAG_ACTIVITY_NO_HISTORY
                            )
                        context.startActivity(alarmIntent)
                    } catch (_: Exception) {
                        // If background-activity-start is blocked, the
                        // notification's full-screen intent will still trigger
                        // the alarm activity when the user interacts with the
                        // notification.
                    }
                }

                // For repeating reminders, schedule the next occurrence.
                if (reminder.repeatIntervalMinutes > 0) {
                    val nextTime = scheduler.computeNextTrigger(
                        lastFireMillis = now,
                        intervalMinutes = reminder.repeatIntervalMinutes,
                        quietHoursEnabled = reminder.quietHoursEnabled,
                        quietStartHour = reminder.quietStartHour,
                        quietEndHour = reminder.quietEndHour
                    )
                    dao.updateNextTrigger(reminder.id, nextTime)
                    scheduler.schedule(reminder.copy(nextTriggerAtMillis = nextTime))
                } else {
                    dao.setEnabled(reminder.id, false)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
