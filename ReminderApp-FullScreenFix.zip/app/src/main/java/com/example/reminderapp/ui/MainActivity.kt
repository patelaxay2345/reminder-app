package com.example.reminderapp.ui

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.reminderapp.R
import com.example.reminderapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: ReminderViewModel by viewModels()
    private lateinit var adapter: ReminderAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        adapter = ReminderAdapter(
            onClick = { reminder ->
                val i = Intent(this, AddEditReminderActivity::class.java)
                i.putExtra(AddEditReminderActivity.EXTRA_ID, reminder.id)
                startActivity(i)
            },
            onToggle = { reminder, checked ->
                viewModel.toggleEnabled(reminder, checked)
            },
            onLongPress = { reminder ->
                AlertDialog.Builder(this)
                    .setTitle("Delete reminder?")
                    .setMessage("\"${reminder.title}\" will be removed.")
                    .setPositiveButton("Delete") { _, _ -> viewModel.delete(reminder) }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        )

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        viewModel.reminders.observe(this) { list ->
            adapter.submitList(list)
            binding.emptyView.visibility =
                if (list.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        }

        binding.fabAdd.setOnClickListener {
            startActivity(Intent(this, AddEditReminderActivity::class.java))
        }

        requestNotificationPermissionIfNeeded()
    }

    override fun onResume() {
        super.onResume()
        // Check permissions every time the user comes back to the main screen,
        // so newly-revoked permissions surface immediately and the user can
        // grant them at any time, not just first launch.
        checkAndPromptPermissions()
    }

    override fun onCreateOptionsMenu(menu: android.view.Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: android.view.MenuItem): Boolean {
        if (item.itemId == R.id.action_settings) {
            startActivity(Intent(this, SettingsActivity::class.java))
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ActivityCompat.checkSelfPermission(
                    this, Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001
                )
            }
        }
    }

    /**
     * Checks for the Android 14+ full-screen intent permission and the
     * "Display over other apps" permission. If either is missing, shows an
     * unmissable dialog explaining what's wrong and how to fix it.
     */
    private fun checkAndPromptPermissions() {
        val missing = mutableListOf<String>()

        // Android 14+ full-screen intent
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val nm = getSystemService(android.app.NotificationManager::class.java)
            if (nm != null && !nm.canUseFullScreenIntent()) {
                missing.add("full_screen")
            }
        }

        // Display-over-other-apps (works on Android 6+) — needed so we can
        // launch the alarm activity from the background reliably.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            !Settings.canDrawOverlays(this)
        ) {
            missing.add("overlay")
        }

        if (missing.isEmpty()) return

        val msgBuilder = StringBuilder()
        msgBuilder.append("For reminders to pop up like an alarm (instead of just a quiet notification), you need to grant the following:\n\n")
        if (missing.contains("full_screen")) {
            msgBuilder.append("• Allow full-screen alerts\n")
        }
        if (missing.contains("overlay")) {
            msgBuilder.append("• Display over other apps\n")
        }
        msgBuilder.append("\nWithout these, your reminders will only show as a notification banner.")

        AlertDialog.Builder(this)
            .setTitle("Permissions needed for alarm-style reminders")
            .setMessage(msgBuilder.toString())
            .setCancelable(false)
            .setPositiveButton("Grant") { _, _ ->
                if (missing.contains("full_screen")) openFullScreenSettings()
                else if (missing.contains("overlay")) openOverlaySettings()
            }
            .setNegativeButton("Skip for now", null)
            .show()
    }

    private fun openFullScreenSettings() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE) return
        try {
            startActivity(
                Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT)
                    .setData(Uri.parse("package:$packageName"))
            )
        } catch (_: Exception) {
            // Fallback to the general app settings page if the specific
            // settings intent isn't available on this OEM.
            openAppDetails()
        }
    }

    private fun openOverlaySettings() {
        try {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
                    .setData(Uri.parse("package:$packageName"))
            )
        } catch (_: Exception) {
            openAppDetails()
        }
    }

    private fun openAppDetails() {
        try {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(Uri.parse("package:$packageName"))
            )
        } catch (_: Exception) { /* nothing more we can do */ }
    }
}
