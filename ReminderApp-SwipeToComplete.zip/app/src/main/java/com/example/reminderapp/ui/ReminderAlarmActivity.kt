package com.example.reminderapp.ui

import android.animation.ObjectAnimator
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.reminderapp.data.ReminderDatabase
import com.example.reminderapp.databinding.ActivityReminderAlarmBinding
import com.example.reminderapp.notification.AlarmScheduler
import com.example.reminderapp.utils.ReminderContent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Full-screen alarm activity that takes over the device when a reminder fires.
 *
 * Behaves like an incoming call:
 *  - Pops over the lock screen, turns the screen on
 *  - Plays the alarm sound continuously, vibrates in a pattern
 *  - Cannot be dismissed except via the Complete or Snooze buttons
 *  - Shows a randomized emoji + wellness quote for variety
 *  - Animates the emoji with a gentle scale pulse for visual interest
 */
class ReminderAlarmActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_REMINDER_ID = "reminder_id"
        const val SNOOZE_MINUTES = 10
    }

    private lateinit var binding: ActivityReminderAlarmBinding
    private var reminderId: Long = -1L
    private var ringtone: android.media.Ringtone? = null
    private var vibrator: Vibrator? = null
    private var pulseAnimator: ObjectAnimator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupLockScreenFlags()

        binding = ActivityReminderAlarmBinding.inflate(layoutInflater)
        setContentView(binding.root)

        reminderId = intent.getLongExtra(EXTRA_REMINDER_ID, -1L)
        if (reminderId == -1L) { finish(); return }

        renderQuote()
        loadReminderInfo()
        startAlarmSound()
        startVibration()
        startEmojiAnimation()

        // Configure the two swipe-to-confirm controls.
        binding.snoozeSwipe.configure(
            label = "Slide to snooze 10 min",
            trackColorHex = "#FFA726",
            iconChar = "⏰"
        )
        binding.snoozeSwipe.onComplete = { onSnooze() }

        binding.completeSwipe.configure(
            label = "Slide to mark complete",
            trackColorHex = "#43A047",
            iconChar = "✓"
        )
        binding.completeSwipe.onComplete = { onComplete() }
    }

    /** Block back press — user has to act on the reminder. */
    @Deprecated("Intentional override")
    override fun onBackPressed() { /* swallow */ }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // If the activity is re-launched while still showing (e.g. another
        // reminder fires), update to the new reminder.
        val newId = intent.getLongExtra(EXTRA_REMINDER_ID, -1L)
        if (newId != -1L && newId != reminderId) {
            reminderId = newId
            loadReminderInfo()
            renderQuote()
        }
    }

    private fun setupLockScreenFlags() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            (getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager)
                ?.requestDismissKeyguard(this, null)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }
    }

    private fun loadReminderInfo() {
        lifecycleScope.launch {
            val reminder = withContext(Dispatchers.IO) {
                ReminderDatabase.getInstance(this@ReminderAlarmActivity)
                    .reminderDao().getById(reminderId)
            } ?: run { finish(); return@launch }

            binding.titleText.text = reminder.title
            binding.descText.text = if (reminder.description.isBlank()) "" else reminder.description
            binding.descText.visibility = if (reminder.description.isBlank())
                android.view.View.GONE else android.view.View.VISIBLE

            binding.categoryText.text = reminder.category.uppercase()
            binding.emojiText.text = ReminderContent.randomEmojiForCategory(reminder.category)
        }
    }

    private fun renderQuote() {
        val quote = ReminderContent.randomQuote()
        binding.quoteText.text = "\u201C${quote.text}\u201D"
        binding.quoteAuthor.text = "— ${quote.author}"
    }

    private fun startEmojiAnimation() {
        // Gentle pulse: scale 1.0 -> 1.08 -> 1.0, repeating.
        pulseAnimator = ObjectAnimator.ofFloat(binding.emojiText, "scaleX", 1.0f, 1.08f, 1.0f).apply {
            duration = 1400
            repeatCount = ObjectAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
        ObjectAnimator.ofFloat(binding.emojiText, "scaleY", 1.0f, 1.08f, 1.0f).apply {
            duration = 1400
            repeatCount = ObjectAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
    }

    private fun startAlarmSound() {
        try {
            val uri: Uri = RingtoneManager.getActualDefaultRingtoneUri(
                this, RingtoneManager.TYPE_ALARM
            ) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

            ringtone = RingtoneManager.getRingtone(this, uri)?.apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    audioAttributes = AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                    isLooping = true
                }
                play()
            }
        } catch (_: Exception) { /* sound is best-effort */ }
    }

    @Suppress("DEPRECATION")
    private fun startVibration() {
        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        val pattern = longArrayOf(0, 800, 600)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
        } else {
            vibrator?.vibrate(pattern, 0)
        }
    }

    private fun stopFeedback() {
        try { ringtone?.stop() } catch (_: Exception) {}
        try { vibrator?.cancel() } catch (_: Exception) {}
        pulseAnimator?.cancel()
    }

    private fun onComplete() {
        stopFeedback()
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                val dao = ReminderDatabase.getInstance(this@ReminderAlarmActivity).reminderDao()
                val reminder = dao.getById(reminderId) ?: return@withContext
                if (reminder.repeatIntervalMinutes == 0) {
                    dao.setEnabled(reminder.id, false)
                    AlarmScheduler(this@ReminderAlarmActivity).cancel(reminder.id)
                }
                // For repeating reminders, the next occurrence was already
                // scheduled by ReminderAlarmReceiver before this screen opened.
            }
            val nm = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
            nm.cancel(reminderId.toInt())
            finishAndRemoveTask()
        }
    }

    private fun onSnooze() {
        stopFeedback()
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                val dao = ReminderDatabase.getInstance(this@ReminderAlarmActivity).reminderDao()
                val reminder = dao.getById(reminderId) ?: return@withContext
                val newTime = System.currentTimeMillis() + SNOOZE_MINUTES * 60_000L
                val updated = reminder.copy(nextTriggerAtMillis = newTime, isEnabled = true)
                dao.update(updated)
                AlarmScheduler(this@ReminderAlarmActivity).schedule(updated)
            }
            val nm = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
            nm.cancel(reminderId.toInt())
            finishAndRemoveTask()
        }
    }

    override fun onDestroy() {
        stopFeedback()
        super.onDestroy()
    }
}
