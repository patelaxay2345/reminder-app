package com.example.reminderapp.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.max
import kotlin.math.min

/**
 * A "slide to confirm" control — like the dismiss gesture on Samsung's alarm
 * clock or the unlock slider on older iPhones.
 *
 * Visual:
 *   ┌────────────────────────────────────────────────────┐
 *   │  ●━━━━━━━━━━━━━ Slide to Complete ━━━━━━━━━━━━━━  │
 *   └────────────────────────────────────────────────────┘
 *
 * The thumb (●) follows the user's finger. If released past 80% of the track,
 * it animates the rest of the way and fires onComplete. If released earlier,
 * it springs back to the start. This prevents accidental dismissal — the user
 * has to make a deliberate gesture across the whole track.
 *
 * Colors and label are configurable so the same control works for both the
 * Snooze (orange) and Complete (green) actions.
 */
class SwipeToActionView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var trackColor: Int = Color.parseColor("#43A047")    // green default
    private var thumbColor: Int = Color.WHITE
    private var labelColor: Int = Color.WHITE
    private var label: String = "Slide to confirm"
    private var thumbIcon: String = "→"

    /** Called when the user successfully swipes all the way across. */
    var onComplete: (() -> Unit)? = null

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = labelColor
        textAlign = Paint.Align.CENTER
        textSize = sp(15f)
        isFakeBoldText = true
    }
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = sp(22f)
        isFakeBoldText = true
    }

    private val trackRect = RectF()
    private val thumbRect = RectF()
    private var thumbX: Float = 0f
    private val padding: Float = dp(4f)
    private var thumbDiameter: Float = 0f
    private var dragging: Boolean = false
    private var startTouchX: Float = 0f
    private var fired: Boolean = false

    /** Configure colors and text. Call before the view is laid out. */
    fun configure(
        label: String,
        trackColorHex: String,
        iconChar: String = "→"
    ) {
        this.label = label
        this.trackColor = Color.parseColor(trackColorHex)
        this.thumbIcon = iconChar
        this.iconPaint.color = trackColor
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        thumbDiameter = h - padding * 2
        thumbX = padding
        trackRect.set(0f, 0f, w.toFloat(), h.toFloat())
        updateThumbRect()
    }

    private fun updateThumbRect() {
        thumbRect.set(thumbX, padding, thumbX + thumbDiameter, padding + thumbDiameter)
    }

    override fun onDraw(canvas: Canvas) {
        // Track
        trackPaint.color = trackColor
        val trackRadius = height / 2f
        canvas.drawRoundRect(trackRect, trackRadius, trackRadius, trackPaint)

        // Label — fades out as the thumb approaches it
        val maxThumbX = width - padding - thumbDiameter
        val progress = (thumbX - padding) / max(1f, maxThumbX - padding)
        labelPaint.alpha = ((1f - progress) * 255).toInt().coerceIn(40, 255)
        labelPaint.color = labelColor
        val centerY = height / 2f - (labelPaint.descent() + labelPaint.ascent()) / 2f
        canvas.drawText(label, width / 2f, centerY, labelPaint)

        // Thumb (white circle)
        thumbPaint.color = thumbColor
        canvas.drawOval(thumbRect, thumbPaint)

        // Icon inside thumb
        val iconY = thumbRect.centerY() - (iconPaint.descent() + iconPaint.ascent()) / 2f
        canvas.drawText(thumbIcon, thumbRect.centerX(), iconY, iconPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (fired) return true
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                if (event.x in thumbRect.left - dp(20f)..thumbRect.right + dp(20f)) {
                    dragging = true
                    startTouchX = event.x - thumbX
                    parent?.requestDisallowInterceptTouchEvent(true)
                    return true
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragging) {
                    val newX = event.x - startTouchX
                    val maxX = width - padding - thumbDiameter
                    thumbX = min(maxX, max(padding, newX))
                    updateThumbRect()
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    dragging = false
                    val maxX = width - padding - thumbDiameter
                    val progress = (thumbX - padding) / max(1f, maxX - padding)
                    if (progress >= 0.8f) {
                        // Past threshold — slide to end and fire.
                        animateToEnd(maxX)
                    } else {
                        // Bounce back to start.
                        animateToStart()
                    }
                }
            }
        }
        return true
    }

    private fun animateToEnd(maxX: Float) {
        fired = true
        ValueAnimator.ofFloat(thumbX, maxX).apply {
            duration = 180
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                thumbX = it.animatedValue as Float
                updateThumbRect()
                invalidate()
            }
            start()
        }
        postDelayed({ onComplete?.invoke() }, 200)
    }

    private fun animateToStart() {
        ValueAnimator.ofFloat(thumbX, padding).apply {
            duration = 220
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                thumbX = it.animatedValue as Float
                updateThumbRect()
                invalidate()
            }
            start()
        }
    }

    /** Allow the alarm activity to reset state for a fresh display. */
    fun reset() {
        fired = false
        thumbX = padding
        updateThumbRect()
        invalidate()
    }

    private fun dp(value: Float): Float =
        value * resources.displayMetrics.density

    private fun sp(value: Float): Float =
        value * resources.displayMetrics.scaledDensity
}
