package com.example.reminderapp.ui

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.reminderapp.data.ReminderDatabase
import com.example.reminderapp.databinding.ActivityReminderAlarmBinding
import com.example.reminderapp.notification.AlarmScheduler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Full-screen "alarm" activity that pops up when a reminder fires.
 *
 * Behaves like the system alarm clock or an incoming call:
 *  - Shows over the lock screen
 *  - Turns the screen on
 *  - Plays the alarm sound continuously
 *  - Vibrates in a loop
 *  - Cannot be dismissed except by tapping Complete or Snooze
 */
class ReminderAlarmActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_REMINDER_ID = "reminder_id"
        const val SNOOZE_MINUTES = 10
    }

    private lateinit var binding: ActivityReminderAlarmBinding
    private var reminderId: Long = -1L
    private var ringtone: android.media.Ringtone? = null
    private var vibrator: Vibrator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Show over the lock screen and turn the screen on, like an alarm.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            km.requestDismissKeyguard(this, null)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }

        binding = ActivityReminderAlarmBinding.inflate(layoutInflater)
        setContentView(binding.root)

        reminderId = intent.getLongExtra(EXTRA_REMINDER_ID, -1L)
        if (reminderId == -1L) { finish(); return }

        loadReminderInfo()
        startAlarmSound()
        startVibration()

        binding.completeButton.setOnClickListener { onComplete() }
        binding.snoozeButton.setOnClickListener { onSnooze() }
    }

    /** Block the back button so the user has to act on the reminder. */
    override fun onBackPressed() { /* Intentionally empty. */ }

    private fun loadReminderInfo() {
        lifecycleScope.launch {
            val reminder = withContext(Dispatchers.IO) {
                ReminderDatabase.getInstance(this@ReminderAlarmActivity)
                    .reminderDao().getById(reminderId)
            } ?: run { finish(); return@launch }

            binding.titleText.text = reminder.title
            binding.descText.text = if (reminder.description.isBlank())
                "Reminder" else reminder.description
            binding.categoryText.text = reminder.category
        }
    }

    private fun startAlarmSound() {
        try {
            // Prefer alarm ringtone for max attention; fall back to default notification.
            val uri: Uri = RingtoneManager.getActualDefaultRingtoneUri(
                this, RingtoneManager.TYPE_ALARM
            ) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

            ringtone = RingtoneManager.getRingtone(this, uri)?.apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    audioAttributes = AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                    isLooping = true
                }
                play()
            }
        } catch (e: Exception) {
            // Sound is best-effort; vibration still runs.
        }
    }

    @Suppress("DEPRECATION")
    private fun startVibration() {
        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        // Pattern: wait 0ms, vibrate 800ms, pause 600ms, repeat from index 0
        val pattern = longArrayOf(0, 800, 600)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
        } else {
            vibrator?.vibrate(pattern, 0)
        }
    }

    private fun stopAlarmFeedback() {
        try { ringtone?.stop() } catch (_: Exception) {}
        try { vibrator?.cancel() } catch (_: Exception) {}
    }

    /** User tapped "Complete" — mark done, dismiss notification, finish. */
    private fun onComplete() {
        stopAlarmFeedback()
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                val dao = ReminderDatabase.getInstance(this@ReminderAlarmActivity).reminderDao()
                val reminder = dao.getById(reminderId) ?: return@withContext
                if (reminder.repeatIntervalMinutes == 0) {
                    // One-time reminder — disable.
                    dao.setEnabled(reminder.id, false)
                    AlarmScheduler(this@ReminderAlarmActivity).cancel(reminder.id)
                }
                // For repeating reminders, the next occurrence was already scheduled
                // by ReminderAlarmReceiver before this screen opened.
            }
            // Cancel the persistent notification that was posted alongside this screen.
            val nm = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
            nm.cancel(reminderId.toInt())
            finishAndRemoveTask()
        }
    }

    /** User tapped "Snooze" — reschedule for SNOOZE_MINUTES from now. */
    private fun onSnooze() {
        stopAlarmFeedback()
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                val dao = ReminderDatabase.getInstance(this@ReminderAlarmActivity).reminderDao()
                val reminder = dao.getById(reminderId) ?: return@withContext
                val newTime = System.currentTimeMillis() + SNOOZE_MINUTES * 60_000L
                val updated = reminder.copy(nextTriggerAtMillis = newTime, isEnabled = true)
                dao.update(updated)
                AlarmScheduler(this@ReminderAlarmActivity).schedule(updated)
            }
            val nm = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
            nm.cancel(reminderId.toInt())
            finishAndRemoveTask()
        }
    }

    override fun onDestroy() {
        stopAlarmFeedback()
        super.onDestroy()
    }
}
