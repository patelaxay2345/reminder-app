package com.example.reminderapp.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.reminderapp.data.Reminder
import com.example.reminderapp.receiver.NotificationActionReceiver
import com.example.reminderapp.ui.ReminderAlarmActivity

object NotificationHelper {

    private const val CHANNEL_ID = "reminders_channel_v2"
    private const val CHANNEL_NAME = "Reminder Alarms"

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                val alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                val audioAttrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()

                val channel = NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Persistent reminders that require action to dismiss"
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 800, 600, 800, 600)
                    setSound(alarmSound, audioAttrs)
                    lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
                    setBypassDnd(false)
                }
                nm.createNotificationChannel(channel)
            }
        }
    }

    /**
     * Posts a high-priority, ongoing reminder notification. The notification:
     *  - Is "ongoing" (cannot be swiped away)
     *  - Carries a full-screen intent that launches the alarm activity even
     *    when the device is locked
     *  - Has Complete and Snooze action buttons inside the notification too,
     *    in case the alarm activity is dismissed by the system
     */
    fun showReminderNotification(context: Context, reminder: Reminder) {
        ensureChannel(context)

        // Full-screen intent — launches the alarm activity over the lock screen.
        val fullScreenIntent = Intent(context, ReminderAlarmActivity::class.java).apply {
            putExtra(ReminderAlarmActivity.EXTRA_REMINDER_ID, reminder.id)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val fullScreenPending = PendingIntent.getActivity(
            context, reminder.id.toInt(), fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Tap on notification body — also opens the alarm activity.
        val tapPending = fullScreenPending

        // Complete action
        val completeIntent = Intent(context, NotificationActionReceiver::class.java).apply {
            action = NotificationActionReceiver.ACTION_DONE
            putExtra(AlarmScheduler.EXTRA_REMINDER_ID, reminder.id)
        }
        val completePending = PendingIntent.getBroadcast(
            context, (reminder.id * 10 + 2).toInt(), completeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Snooze action
        val snoozeIntent = Intent(context, NotificationActionReceiver::class.java).apply {
            action = NotificationActionReceiver.ACTION_SNOOZE
            putExtra(AlarmScheduler.EXTRA_REMINDER_ID, reminder.id)
        }
        val snoozePending = PendingIntent.getBroadcast(
            context, (reminder.id * 10 + 1).toInt(), snoozeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(reminder.title)
            .setContentText(reminder.description.ifBlank { "Tap to act on reminder" })
            .setStyle(NotificationCompat.BigTextStyle().bigText(reminder.description))
            .setContentIntent(tapPending)
            .setFullScreenIntent(fullScreenPending, true)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)        // user cannot swipe away
            .setAutoCancel(false)
            .addAction(0, "✓ Complete", completePending)
            .addAction(0, "⏰ Snooze 10 min", snoozePending)

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(reminder.id.toInt(), builder.build())
    }
}
